package Starsinthesky_TristanSmith_000825589;


import javafx.application.Application;
        import javafx.scene.Group;
        import javafx.scene.Scene;
        import javafx.scene.canvas.Canvas;
        import javafx.scene.canvas.GraphicsContext;
        import javafx.scene.paint.Color;
        import javafx.scene.text.Font;
        import javafx.stage.Stage;

        import java.util.Scanner;

        import static javafx.application.Application.launch;

/**
 *this code creates a night sky by displayig random stars acrross the scrren with a build in template
 * theres a scanner thatr aloows users to enter values for star cords and then the programm asks you values to indicate where the stars will go
 * lastly the programm displays a line to show the stars connected in a constolation.
 *
 * @author Tristan smith
 */
public class Starsinthesky_TristanSmith_000825589 extends Application {

    /**
     * Start method (use this instead of main).
     *
     * @param stage The FX stage to draw on
     * @throws Exception
     */
    @Override
    public void start(Stage stage) throws Exception {
        Group root = new Group();
        Scene scene = new Scene(root, Color.BLACK);
        Canvas canvas = new Canvas(800, 800); // Set canvas Size in Pixels
        stage.setTitle("stars in the sky"); // Set window title
        root.getChildren().add(canvas);
        stage.setScene(scene);
        GraphicsContext gc = canvas.getGraphicsContext2D();

        // YOUR CODE STARTS HERE
        //first we create the template of the star
        gc.setFill(Color.WHITE);
        //creates a list of integers to go by such as indicating the cords for stars
        int Counter = 0, Numstars, Xstars, Ystars,Oldx = 0,Oldy=0;
        String name;
        //a for loop that indicates the doubles of the random stars in the night sky i have created
        for (double z = 1; z <= 40; z++) {
            double x = Math.random() * 800;
            double y = Math.random() * 800;
            gc.fillOval(x, y, 4, 4);

        }
        //the start of the user scanner asking the user for the number of stars in their constellation
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter how many stars you would like in your constellation: ");
        Numstars = sc.nextInt();
        //asks the user for the name of there constolation
        System.out.print("Enter the name of your constellation: ");
        name = sc.next();
        //Places the name of the constellation at the top of the screen.
        gc.setFill(Color.MAGENTA);
        gc.fillText("-Constellation Name  " +name, 20, 20);
        //Start of the counter to indicate when the number of stars the user wants has been reached to know when to stop the loop
        while (Counter < Numstars) {
            while(true) {
                //indicates the x cords of the stars
                System.out.print("Enter the x coordinates for your star, numbers between 0 and 800: ");
                Xstars = sc.nextInt();
                //This if statement makes a loop that will make sure the user enter reasonable cords for there stars.
                if (Xstars > 800 || Xstars < 0) {
                    System.out.println("Please enter a value between 0 and 800");

                } else {

                    break;
                }
            }
            while(true) {
                //Indicates the y cords of the stars
                System.out.print("Enter the y cords for your star: ");
                Ystars = sc.nextInt();
                //Does another loop to make sure user enters proper cords
                if (Ystars > 800 || Ystars < 0) {
                    System.out.println("Please enter a value between 0 and 800");

                } else {
                    break;
                }
            }
            //this area creats the color of the star and the line between the stars to make the consolation
            gc.setFill(Color.YELLOWGREEN);
            gc.fillOval(Xstars, Ystars, 4, 4);

            if(Counter >= 1){
                gc.setStroke(Color.BLUE);
                gc.strokeLine(Oldx,Oldy,Xstars,Ystars);

            }

            Oldx = Xstars;
            Oldy = Ystars;


            Counter++;

        }
        gc.setFill(Color.WHITE);
        gc.setFont(Font.font("Comic sans MS", 10));
        gc.fillText("Tristan Smith 000825589", 350, 770);

        // YOUR CODE STOPS HERE
        stage.show();
    }

    /**
     * The actual main method that launches the app.
     *
     * @param args unused
     */
    public static void main(String[] args) {
        launch(args);
    }
}
